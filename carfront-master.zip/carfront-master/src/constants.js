export const SERVER_URL = 'http://CUVRA00A0586:8080/'
