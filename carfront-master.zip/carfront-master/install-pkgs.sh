#!/bin/bash
# set -x

npm install react-table --save

npm install react-confirm-alert --save

npm install react-skylight --save

npm install react-csv --save

npm install @material-ui/core --save

npm install @elastic/apm-rum --save

